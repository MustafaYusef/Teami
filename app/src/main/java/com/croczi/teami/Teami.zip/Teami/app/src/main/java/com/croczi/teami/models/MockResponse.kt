package com.croczi.teami.models

class MockResponse {

}
