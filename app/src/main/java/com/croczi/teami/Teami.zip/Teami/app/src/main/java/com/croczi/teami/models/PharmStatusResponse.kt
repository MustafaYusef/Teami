package com.croczi.teami.models

class PharmStatusResponse(
    var PharmacyStatus:List<StatusResource>
)