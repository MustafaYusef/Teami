package com.croczi.teami.models

class FeedbackResponse(
    var activity: ActivityResponse
)