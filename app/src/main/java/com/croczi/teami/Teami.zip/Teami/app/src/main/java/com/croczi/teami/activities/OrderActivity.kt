package com.croczi.teami.activities

import android.content.DialogInterface
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AppCompatDelegate
import android.support.v7.widget.CardView
import android.view.LayoutInflater
import android.widget.*
import com.croczi.teami.R
import com.croczi.teami.models.*
import com.croczi.teami.retrofit.NetworkTools
import com.croczi.teami.retrofit.RepresentativesInterface
import com.croczi.teami.retrofit.addTLSSupport
import com.croczi.teami.utils.Consts
import com.croczi.teami.utils.Consts.BASE_URL
import com.croczi.teami.utils.Consts.LOGIN_RESPONSE_SHARED
import com.croczi.teami.utils.getID
import com.croczi.teami.utils.showMessageOK
import com.orhanobut.hawk.Hawk
import kotlinx.android.synthetic.main.activity_order.*
import kotlinx.android.synthetic.main.items_ordered.view.*
import kotlinx.android.synthetic.main.order_item_layout.view.itemNameTV
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class OrderActivity : AppCompatActivity() {

    private var selectedItems: ArrayList<Item> = arrayListOf()
    private lateinit var allItems: List<Item>
    private var item_ids: ArrayList<Int> = arrayListOf()
    private var quantities: ArrayList<Int> = arrayListOf()
    private lateinit var token: String

    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        doneOrderBtn.setOnClickListener {
            postOrder()
        }

        val loginResponse = Hawk.get<LoginResponse>(LOGIN_RESPONSE_SHARED)
        if (loginResponse != null) {
            token = loginResponse.token
        }
        getItems()
    }

    private fun getItems() {
        var retrofitBuilder = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP) {
            retrofitBuilder.addTLSSupport()
        }
        val retrofit = retrofitBuilder.build()
        val itemsInterface = retrofit.create(RepresentativesInterface::class.java)
        val itemsResponse = itemsInterface.getItems(token, getID(this))
        itemsResponse.enqueue(object : Callback<ItemsResponse> {
            override fun onFailure(call: retrofit2.Call<ItemsResponse>, t: Throwable) {
                Toast.makeText(this@OrderActivity, t.message, Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: retrofit2.Call<ItemsResponse>,
                response: Response<ItemsResponse>
            ) {
                response.body()?.let {
                    val items = it.items
                    allItems = items
                    prepareItems(items)
                }
            }
        })
    }

    private fun postOrder() {
        val resource: MyResources = intent.getParcelableExtra("RESOURCE")
        val orderRequest = OrderRequest(
            token,
            getID(this),
            item_ids,
            quantities,
            resource.resourceType,
            resource.id
        )
        NetworkTools.postOrder(orderRequest, {
            showMessageOK(this@OrderActivity,
                getString(R.string.done),
                getString(R.string.order_successful),
                DialogInterface.OnClickListener { dialog, which -> dialog.dismiss() })
            this@OrderActivity.finish()
        }, { message ->
            Toast.makeText(this@OrderActivity, message, Toast.LENGTH_LONG).show()
        })
    }

    private fun prepareItems(items: List<Item>) {
        val arrayAdapter = ArrayAdapter<Item>(this, R.layout.text_view_layout, items)
        ItemNameTV.setAdapter(arrayAdapter)
        ItemNameTV.setOnClickListener {
            ItemNameTV.showDropDown()
        }
        ItemNameTV.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                ItemNameTV.showDropDown()
            }
        }
        ItemNameTV.threshold = 0
        ItemNameTV.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
                val item = arrayAdapter.getItem(position) as Item
                ItemNameTV.setText(item.name)
                addItemBtn.setOnClickListener {
                    if (quantityET.text.isNotBlank() && ItemNameTV.text.isNotBlank()) {
                        quantities.add(quantityET.text.toString().toInt())
                        item_ids.add(item.id)
                        selectedItems.add(item)
                        ItemNameTV.text.clear()
                        quantityET.text.clear()
                        addItem()
                    }
                }
            }
    }

    private fun addItem() {
        val view = LayoutInflater.from(this).inflate(R.layout.items_ordered, null)
        view.itemNameTV.text = selectedItems.last().name
        view.quantityTV.text = quantities.last().toString()
        val laypar =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        laypar.setMargins(8, 16, 8, 16)
        view.layoutParams = laypar
        view.id = selectedItems.last().id
        view.rmvItemBtn.setOnClickListener {
            removeItem(view.id.toString())
        }
        itemsLinLay.addView(view)

    }

    private fun removeItem(id: String) {
        val unselected = findViewById<CardView>(id.toInt())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            selectedItems.removeIf { t -> t.id == id.toInt() }
            item_ids.removeIf { t ->
                quantities.removeIf { t2 -> quantities.indexOf(t2) == item_ids.indexOf(t) }
                t == id.toInt()
            }
            itemsLinLay.removeView(unselected)
        }
    }
}
