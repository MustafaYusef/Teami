package com.mustafayusef.sharay.database

import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context

import com.mustafayusef.sharay.database.entitis.MyResourcesLocal


@Database(entities = [MyResourcesLocal::class], version = 2)
public abstract class databaseApp : RoomDatabase() {


    abstract fun resource_Dao(): Resource_Dao


    companion object {
        @Volatile
        private var INSTANCE: databaseApp? = null
        private val Lock=Any()

        operator fun invoke(context: Context)=INSTANCE?: synchronized(Lock){
            INSTANCE?:getDatabase(context).also {
                INSTANCE=it
            }
        }

        fun getDatabase(context: Context)=
            Room.databaseBuilder(
                context.applicationContext,
                databaseApp::class.java,
                "sharay"
            ).fallbackToDestructiveMigration().build()

    }
}



