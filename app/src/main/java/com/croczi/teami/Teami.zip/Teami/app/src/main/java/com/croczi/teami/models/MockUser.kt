package com.croczi.teami.models

class MockUser(
    val name: String?,
    val email: String?,
    val phone: String?,
    val role: String?,
    val reportingTo: String?,
    val id: Int
)
