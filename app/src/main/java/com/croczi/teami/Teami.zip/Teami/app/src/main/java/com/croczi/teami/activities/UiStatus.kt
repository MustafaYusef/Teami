package com.croczi.teami.activities

enum class UiStatus {
    ShowError,
    ShowContent,
    ShowProgress
}