package com.croczi.teami.models

class ForgotResponse(
    var status:String?
)