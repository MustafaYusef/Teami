package com.croczi.teami.models

class ErrorResponseArray(
    var error: List<String>
)