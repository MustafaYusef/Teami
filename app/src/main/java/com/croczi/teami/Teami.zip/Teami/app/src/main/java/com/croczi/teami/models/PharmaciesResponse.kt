package com.croczi.teami.models

class PharmaciesResponse(
    var pharmacies: List<Pharmacy> = listOf()
)