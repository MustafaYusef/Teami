package com.croczi.teami.models

class ForgotRequest(
    var email:String
)