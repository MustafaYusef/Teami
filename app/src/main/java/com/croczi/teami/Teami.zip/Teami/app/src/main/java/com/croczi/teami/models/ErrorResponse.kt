package com.croczi.teami.models

class ErrorResponse(
    var error: String
)