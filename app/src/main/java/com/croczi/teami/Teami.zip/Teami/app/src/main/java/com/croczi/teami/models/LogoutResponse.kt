package com.croczi.teami.models

class LogoutResponse {

}
