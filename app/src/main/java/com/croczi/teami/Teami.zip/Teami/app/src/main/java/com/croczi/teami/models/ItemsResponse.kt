package com.croczi.teami.models

class ItemsResponse(
    var items:List<Item>
)