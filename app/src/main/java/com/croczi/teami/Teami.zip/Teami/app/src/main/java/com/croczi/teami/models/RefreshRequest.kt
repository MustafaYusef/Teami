package com.croczi.teami.models

class RefreshRequest(
    var token: String,
    var phone_id: String
)