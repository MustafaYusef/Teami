package com.croczi.teami.models

class CheckResponse(var success:String)