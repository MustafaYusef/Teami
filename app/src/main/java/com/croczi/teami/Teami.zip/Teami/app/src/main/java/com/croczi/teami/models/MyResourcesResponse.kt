package com.croczi.teami.models

class MyResourcesResponse(
    var Resource:List<MyResources>
)