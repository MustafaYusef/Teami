package com.croczi.teami.models

class Drugstore(
    var id:Int,
    var name:String,
    var area:String,
    var str:String,
    var buildingName:String?,
    var province:String?,
    var phone:String?,
    var email:String?
)