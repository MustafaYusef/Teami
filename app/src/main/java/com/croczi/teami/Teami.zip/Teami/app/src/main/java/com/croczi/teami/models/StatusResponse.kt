package com.croczi.teami.models

class StatusResponse(
    var status:List<StatusResource>
)