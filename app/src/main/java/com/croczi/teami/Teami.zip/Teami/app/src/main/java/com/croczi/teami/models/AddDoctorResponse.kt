package com.croczi.teami.models

class AddDoctorResponse(
    var doctor_id:Int
)