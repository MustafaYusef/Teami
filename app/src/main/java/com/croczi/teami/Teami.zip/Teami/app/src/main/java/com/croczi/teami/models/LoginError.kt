package com.croczi.teami.models

class LoginError(
    var error:String
)