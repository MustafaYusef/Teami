package com.croczi.teami.models

class AddPharmacyResponse(
    var pharmacy_id:Int
)